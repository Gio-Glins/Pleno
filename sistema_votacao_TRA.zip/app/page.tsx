"use client";
import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface Processo {
  id: number;
  titulo: string;
  votos: Voto[];
}

interface Voto {
  membro: string;
  voto: "Favorável" | "Desfavorável" | "Acatar Parcialmente";
}

export default function Home() {
  const [processos, setProcessos] = useState<Processo[]>([]);
  const [usuario, setUsuario] = useState<string>("");

  useEffect(() => {
    const savedData = localStorage.getItem("votacaoTRA");
    if (savedData) {
      setProcessos(JSON.parse(savedData));
    } else {
      setProcessos([
        { id: 1, titulo: "Processo 01", votos: [] },
        { id: 2, titulo: "Processo 02", votos: [] },
      ]);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("votacaoTRA", JSON.stringify(processos));
  }, [processos]);

  const votar = (id: number, voto: "Favorável" | "Desfavorável" | "Acatar Parcialmente") => {
    setProcessos((prev) =>
      prev.map((p) =>
        p.id === id
          ? { ...p, votos: [...p.votos.filter((v) => v.membro !== usuario), { membro: usuario, voto }] }
          : p
      )
    );
  };

  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold mb-6 text-primary">Secretaria do Estado de Meio Ambiente e Sustentabilidade</h1>
      <input
        type="text"
        placeholder="Digite seu nome"
        value={usuario}
        onChange={(e) => setUsuario(e.target.value)}
        className="border p-2 mb-6 w-full rounded"
      />
      {usuario && (
        <Button onClick={() => setUsuario("")} variant="outline" className="mb-4">Logout</Button>
      )}
      <div className="grid gap-4">
        {processos.map((processo) => (
          <Card key={processo.id}>
            <CardContent className="p-4">
              <h2 className="font-semibold text-xl mb-4">{processo.titulo}</h2>
              <div className="flex gap-2 mb-4">
                <Button onClick={() => votar(processo.id, "Favorável")}>Favorável</Button>
                <Button onClick={() => votar(processo.id, "Desfavorável")} variant="destructive">Desfavorável</Button>
                <Button onClick={() => votar(processo.id, "Acatar Parcialmente")} className="bg-blue-500 hover:bg-blue-600">Acatar Parcialmente</Button>
              </div>
              <div>
                <h3 className="font-semibold">Votos:</h3>
                <ul>
                  {processo.votos.map((v, index) => (
                    <li key={index}>{v.membro}: {v.voto}</li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </main>
  );
}
