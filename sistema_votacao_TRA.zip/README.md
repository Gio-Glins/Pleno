# Sistema de Votação TRA

Sistema de votação para plenárias da Secretaria de Estado de Meio Ambiente e Sustentabilidade.

## Autor
Giovanni Glins

## Instruções de Uso

1. Instale as dependências:
```bash
npm install
```

2. Rode o projeto:
```bash
npm run dev
```

## Tecnologias
- Next.js 15
- TypeScript
- TailwindCSS
